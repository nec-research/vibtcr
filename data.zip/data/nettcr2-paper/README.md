# NetTCR2.0
Data is taken from https://github.com/mnielLab/NetTCR-2.0

Commit id: [c2d5ba38150efa97f63621e0087c3a3da7311fe9](https://github.com/mnielLab/NetTCR-2.0/commit/c2d5ba38150efa97f63621e0087c3a3da7311fe9)