# ERGO II
Data is taken from https://github.com/IdoSpringer/ERGO-II/tree/master/Samples

Commit id: [1f0e356ec0efacafd65a2ab7e4dc28c3943485e8](https://github.com/IdoSpringer/ERGO-II/commit/1f0e356ec0efacafd65a2ab7e4dc28c3943485e8)