The `alpha-beta.csv` and `beta.csv` are created with the 
notebook `notebooks/notebooks.classification/dataset-creation.ipynb`