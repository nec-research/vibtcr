# ERGO II
Source code is taken from https://github.com/IdoSpringer/ERGO-II

Commit id: [7a25b90db54252f4691b70af34f0d4f5351941c9](https://github.com/IdoSpringer/ERGO-II/commit/7a25b90db54252f4691b70af34f0d4f5351941c9)