# NetTCR2.0
Source code is taken from https://github.com/mnielLab/NetTCR-2.0

Commit id: [8fa4b04b264f11a2701273c55af34649c0907198](https://github.com/mnielLab/NetTCR-2.0/commit/8fa4b04b264f11a2701273c55af34649c0907198)
