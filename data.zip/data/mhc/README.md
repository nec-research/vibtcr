# NetMHCIIpan-4.0
Data is taken from https://services.healthtech.dtu.dk/suppl/immunology/NAR_NetMHCpan_NetMHCIIpan/